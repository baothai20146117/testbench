/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "string.h"
#include "math.h"
#include "stdio.h"
#include "stdlib.h"
#include "stdbool.h"
#include "usbd_cdc_if.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define BASECLOCK 320000
#define ttc_factor 1
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
float speed_detect(float frequency, float wheel_circumference, int teeth);
void parameter_setup(char buffer[]);
void convertData(char buffer[], float* ptr);
void lcs_setup(char buffer[]);
int PID(int SetSpeed , int CurrentSpeed);
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;

/* USER CODE BEGIN PV */

uint16_t capture_value_f_1,capture_value_f_2,capture_value_r_1,capture_value_r_2;
float freq_f,freq_r;
float speed_f,speed_r;

int tick_f,tick_r;
uint8_t update_flag =0,manualFrontFlag,manualRearFlag;

char sendData_f[19];
char sendData_r[19];


char sendPara[30];

char sendLcs_f[64];
char sendLcs_r[64];


char buffer[64];
int teeth_f,teeth_r;
float wc_f,wc_r;


float* front_speed;
float* front_time;
float* rear_speed;
float* rear_time;

int size_f =0,size_r =0,lcs_item=1;


float lcsFrontSpeedStep,lcsRearSpeedStep,manualFrontSpeedStep,manualRearSpeedStep;

int lcsFrontCount,lcsRearCount,manualFrontCount,manualRearCount;

int lcsFrontTimeStep,lcsRearTimeStep,manualFrontTimeStep,manualRearTimeStep;

float manualFrontSpeed,manualRearSpeed,manualFrontTime,manualRearTime,lcsFrontSpeed,lcsRearSpeed;

float manualFrontOut,manualRearOut;

int tuningPwm;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM4_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{

		/* CALCULATE TONEWHEEL SPEED */
		if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1 )
		{
			capture_value_f_2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);
			if (capture_value_f_2 > capture_value_f_1) freq_f=(BASECLOCK/( capture_value_f_2 - capture_value_f_1));
			else freq_f =(BASECLOCK/( 0xffff + capture_value_f_2 - capture_value_f_1));
			speed_f = speed_detect(freq_f,wc_f,teeth_f );
			snprintf( sendData_f,8,"a%.2f",speed_f);
			CDC_Transmit_FS((uint8_t *)sendData_f, 8);
			capture_value_f_1 = capture_value_f_2;
			tick_f =0;


		}

		if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_2 )
		{
			capture_value_r_2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_2);
			if (capture_value_r_2 > capture_value_r_1) freq_r=(BASECLOCK/( capture_value_r_2 - capture_value_r_1));
			else freq_r =(BASECLOCK/( 0xffff + capture_value_r_2 - capture_value_r_1));
			speed_r = speed_detect(freq_r,wc_r,teeth_r );
			snprintf( sendData_r,8,"b%.2f",speed_r);
			CDC_Transmit_FS((uint8_t *)sendData_r, 8);
			capture_value_r_1 = capture_value_r_2;
			tick_r =0;
		}





}



void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance == TIM3)
	{
		tick_f++;
		if(tick_f == 15) //AFTER 0.15s OF NON-SIGNAL , RETURN SPEED 0
		{
			freq_f =0;
			snprintf( sendData_f,8,"a%d",0); // speed =0
			CDC_Transmit_FS((uint8_t *)sendData_f, 8);
			tick_f = 0;
		}
		tick_r++;
		if(tick_r == 15) //0.15s interrupt
		{
			freq_r =0;
			snprintf( sendData_r,8,"b%d",0); // speed =0
			CDC_Transmit_FS((uint8_t *)sendData_r, 8);
			tick_r = 0;
		}

		/* lcs control fuction */
		switch(update_flag)
		{
			case 1 :
			{
				lcs_item =1;

				lcsFrontTimeStep =  round((front_time[lcs_item]-front_time[lcs_item-1])/0.01);
				lcsFrontSpeedStep = (front_speed[lcs_item]-front_speed[lcs_item-1])/lcsFrontTimeStep;

				lcsRearTimeStep =  round((rear_time[lcs_item]-rear_time[lcs_item-1])/0.01);
				lcsRearSpeedStep = (rear_speed[lcs_item]-rear_speed[lcs_item-1])/lcsRearTimeStep;

				lcsFrontCount=lcsRearCount=0;

				lcsFrontSpeed = lcsRearSpeed =0;

				lcs_item++;
				update_flag =2;
				break;
			}
			case 2 :
			{

				/*FRONT WHEEL LCS CONTROL */
				if(lcsFrontCount < lcsFrontTimeStep)
				  {
					lcsFrontSpeed += lcsFrontSpeedStep;
					TIM4 -> CCR1 = PID(lcsFrontSpeed, speed_f);
					lcsFrontCount++;
				  }
				else
				{
					if (lcs_item< size_f)
					{
					  lcsFrontCount = 0;
					  lcsFrontTimeStep = round((front_time[lcs_item]-front_time[lcs_item-1])/0.01);
					  lcsFrontSpeedStep = (front_speed[lcs_item]-front_speed[lcs_item-1])/lcsFrontTimeStep;

					  lcs_item++;

					}
					else
						{
							snprintf(sendLcs_f,64,"m");
							CDC_Transmit_FS((uint8_t *)sendLcs_f, 64);
						}
				}

				/*REAR WHEEL LCS CONTROL */
				if(lcsRearCount < lcsRearTimeStep)
				  {
					lcsRearSpeed += lcsRearSpeedStep;
					TIM4 -> CCR2 = PID(lcsRearSpeed, speed_r);
					lcsRearCount++;
				  }
				else
				{
					if (lcs_item< size_f)
					{
					  lcsRearCount = 0;
					  lcsRearTimeStep = round((rear_time[lcs_item]-rear_time[lcs_item-1])/0.01);
					  lcsRearSpeedStep = (rear_speed[lcs_item]-rear_speed[lcs_item-1])/lcsRearTimeStep;

					  lcs_item++;

					}
					else
						{
							snprintf(sendLcs_r,64,"n");
							CDC_Transmit_FS((uint8_t *)sendLcs_r, 64);
						}
				}
				break;
			}

			case 0 :
			{
				TIM4 -> CCR1 = 0;
				TIM4 -> CCR2 = 0;
				break;

			}

			/*	MANUAL CONTROL */
			case 3:
			{
				switch (manualFrontFlag)
				{
					case 0:
					{
						manualFrontTimeStep =round( manualFrontTime /0.01);
						manualFrontSpeedStep  = ( manualFrontSpeed - manualFrontOut)/manualFrontTimeStep;
						manualFrontCount =0;
						manualFrontFlag =1;
						break;
					}
					case 1:
					{
						if(manualFrontCount < manualFrontTimeStep)
						{
							manualFrontOut += manualFrontSpeedStep;
							TIM4-> CCR1 = PID(manualFrontOut,speed_f);
							manualFrontCount++;
							break;
						}

					}
				}
				switch (manualRearFlag)
				{
					case 0:
					{
						manualRearTimeStep = round(manualRearTime /0.01);
						manualRearSpeedStep  =  (manualRearSpeed - manualRearOut)/manualRearTimeStep;
						manualRearCount = 0;
						manualRearFlag =1;
						break;
					}
					case 1:
					{
						if(manualRearCount < manualRearTimeStep)
						{
							manualRearOut += manualRearSpeedStep;
							TIM4-> CCR2 = PID(manualRearOut,speed_r);
							manualRearCount++;
							break;
						}

					}
				}
			}

			case 4:
			{
				TIM4 -> CCR1 = tuningPwm;
				break;

			}
		}



	}
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
	front_speed = (float*)malloc(100*sizeof(float));
	front_time = (float*)malloc(100*sizeof(float));
	rear_speed = (float*)malloc(100*sizeof(float));
	rear_time = (float*)malloc(100*sizeof(float));
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_USB_DEVICE_Init();
  MX_TIM4_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_1);
  HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_2);
  HAL_TIM_Base_Start_IT(&htim3);
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_2);

  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USB;
  PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_PLL_DIV1_5;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_IC_InitTypeDef sConfigIC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 225-1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 65535;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_IC_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_FALLING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 15;
  if (HAL_TIM_IC_ConfigChannel(&htim2, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_IC_ConfigChannel(&htim2, &sConfigIC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 7199;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 100-1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 4-1;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 1000-1;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */
  HAL_TIM_MspPostInit(&htim4);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/*	RETURN SPEED IN KMH*/
float speed_detect(float frequency, float wheel_circumference, int teeth)
{
	return (3.6*frequency*ttc_factor*wheel_circumference/teeth);
}

/*	PARAMETER SET UP*/
void parameter_setup(char buffer[])
{
	teeth_f = atoi(&buffer[1]);
	wc_f = atof(&buffer[5]);
	teeth_r = atoi(&buffer[11]);
	wc_r= atof(&buffer[15]);
}


/*	READ LCS FILE INPUT DATA	*/
void lcs_setup(char buffer[])
{

	switch (buffer[1])
	{
		case 'f':

			front_speed[size_f] = atof(&buffer[2]);
			front_time[size_f] = atof(&buffer[10]);
			size_f++;

			break;

		case 'r':

			rear_speed[size_r] = atof(&buffer[2]);
			rear_time[size_r] = atof(&buffer[10]);
			size_r++;

			break;
	}
}




/*	PID VALUE CALCULATE	*/
int PID(int SetSpeed , int CurrentSpeed)
{
	float kp=3.55,ki=13.77,kb=3.875;   // IMC standard
	static float err_windup;
	static float iterm_p = 0;
	static float err_sat = 0;

	int err =(SetSpeed - CurrentSpeed) ;
	float pterm,iterm,pidterm,pid_sat;

	float sample_time = 0.01; // 10ms

	//P term
	pterm = kp*err;

	//I term
	err_windup  = ki*err + kb*err_sat;
	iterm = iterm_p + err_windup*sample_time;


	//reset value
	iterm_p = iterm ;

	//pi term
	pidterm = pterm + iterm ;

	if(pidterm > 500 ) 		pid_sat = 500;

	else if (pidterm<0)		pid_sat = 0;

	else pid_sat = pidterm ;

	err_sat = pid_sat - pidterm;

	return (int)pid_sat;
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
